from HAL.engine.base    import BaseEngine
from HAL.engine.regex   import RegexEngine
from HAL.engine.general import GeneralEngine
from HAL.engine.matrix  import MatrixEngine
from HAL.engine.oneword import OneWordEngine
from HAL.engine.generic import GenericEngine
