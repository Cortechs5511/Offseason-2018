from ntcore import __version__
